import Login from "./components/login";

function App() {
  return (
    <>
      <Login />
    </>
  );
}

export default App;
